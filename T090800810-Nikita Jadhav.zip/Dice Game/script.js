function rollDice() {
    let player1 = Math.floor(Math.random() * 6) + 1;
    let player2 = Math.floor(Math.random() * 6) + 1;
    let player3 = Math.floor(Math.random() * 6) + 1;
    let player4 = Math.floor(Math.random() * 6) + 1;

    document.getElementById("dice1").textContent = getDiceEmoji(player1);
    document.getElementById("dice2").textContent = getDiceEmoji(player2);
    document.getElementById("dice3").textContent = getDiceEmoji(player3);
    document.getElementById("dice4").textContent = getDiceEmoji(player4);

    document.getElementById("score1").textContent = "Score: " + player1;
    document.getElementById("score2").textContent = "Score: " + player2;
    document.getElementById("score3").textContent = "Score: " + player3;
    document.getElementById("score4").textContent = "Score: " + player4;

    let maxScore = Math.max(player1, player2, player3, player4);
    let winners = [];

    if (player1 === maxScore) winners.push("Player 1");
    if (player2 === maxScore) winners.push("Player 2");
    if (player3 === maxScore) winners.push("Player 3");
    if (player4 === maxScore) winners.push("Player 4");

    let winnerText = winners.length > 1 ? `It's a tie! 🏆 ${winners.join(" & ")}` : ` ${winners[0]} Wins✌🏼!`;
    
    document.getElementById("winner").textContent = winnerText;
}


function getDiceEmoji(number) {
    let diceEmojis = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];
    return diceEmojis[number - 1];
}
